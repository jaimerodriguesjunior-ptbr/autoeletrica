import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

// Inicializa Supabase
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export async function POST(req: Request) {
  // === 1. DIAGNÓSTICO DE CHAVE (Para aparecer no Terminal) ===
  const apiKey = process.env.GEMINI_API_KEY;
  
  if (!apiKey) {
      console.error("❌ [DIAGNÓSTICO] O código NÃO está lendo nenhuma chave no .env.local");
      return NextResponse.json({ text: "Erro: Chave não configurada no servidor." });
  } else {
      // Mostra apenas os 5 primeiros dígitos para segurança
      console.log(`🔑 [DIAGNÓSTICO] Chave lida: ${apiKey.substring(0, 5)}... (Tamanho total: ${apiKey.length})`);
  }
  // ==========================================================

  console.log("🤖 [API IA] Iniciando requisição (Gemini 3.0)...");

  try {
    const { message } = await req.json();

    // 2. Busca de Dados (Contexto)
    // Financeiro
    const { data: financeiro } = await supabase.from('transactions').select('amount, type');
    const receita = financeiro?.filter(t => t.type === 'income').reduce((acc, t) => acc + Number(t.amount), 0) || 0;
    const despesa = financeiro?.filter(t => t.type === 'expense').reduce((acc, t) => acc + Number(t.amount), 0) || 0;

    // OS
    const { data: os } = await supabase.from('work_orders').select('status');
    const osAbertas = os?.filter(o => ['orcamento', 'aprovado', 'em_servico', 'aguardando_peca'].includes(o.status)).length || 0;

    // Estoque
    const { data: produtos } = await supabase.from('products').select('nome, estoque_atual, estoque_min');
    const criticos = produtos?.filter(p => p.estoque_atual <= p.estoque_min).map(p => `${p.nome} (${p.estoque_atual})`).join(', ') || "Nenhum";

    // 3. Monta o Prompt
    const context = `
      Você é a IA da oficina AutoPro.
      DADOS:
      - Finanças: Receita R$ ${receita.toFixed(2)}, Despesa R$ ${despesa.toFixed(2)}.
      - Operacional: ${osAbertas} OSs abertas.
      - Estoque Baixo: ${criticos}.
      
      Pergunta do usuário: ${message}
    `;

    // 4. Chamada ao Google Gemini 3.0
    const model = 'gemini-3-pro-preview'; 
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

    console.log(`📡 [API IA] Enviando para ${model}...`);

    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: context }] }]
      })
    });

    if (!response.ok) {
        const errorDetails = await response.text();
        console.error("❌ [API IA] Erro do Google:", response.status, errorDetails);
        return NextResponse.json({ text: `Erro (${response.status}): Verifique o terminal para ver o motivo.` });
    }

    const data = await response.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || "A IA não retornou texto.";

    return NextResponse.json({ text });

  } catch (error: any) {
    console.error("💥 [API IA] Erro CRÍTICO:", error);
    return NextResponse.json({ text: "Erro interno no servidor." });
  }
}